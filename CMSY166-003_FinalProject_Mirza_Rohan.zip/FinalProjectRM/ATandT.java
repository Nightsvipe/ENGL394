public class ATandT extends Carrier{
    
	public ATandT(){
		super("AT&T");
	}
    
    
}