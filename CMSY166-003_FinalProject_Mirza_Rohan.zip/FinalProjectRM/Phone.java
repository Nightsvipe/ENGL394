abstract public class Phone {
    
    public abstract void initialize(boolean memberCA);
    
}
