public class Tmobile extends Carrier{
    
    public Tmobile(){
		super("T-Mobile");
	}
        
}
