public class Verizon extends Carrier{
    

	public Verizon(){
		super("Verizon");
	}
    
    
    
}
